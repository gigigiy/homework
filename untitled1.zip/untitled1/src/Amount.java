public class Amount {
    private double amount;
    private  String transactionType;

    public Amount(double amount, String transactionType) {
        this.amount = amount;
        this.transactionType = transactionType;
    }

    public String getInfo(){
        return transactionType + "->" + amount;

    }

}
