package all;

public class Cource {
    private String name;
    private int id;

    public Cource(String oop, int i) {
    }
}
