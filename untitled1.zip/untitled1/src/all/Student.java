package all;

import all.Cource;

import java.util.ArrayList;

public class Student {
    private String name;
    private int id;

    ArrayList<Cource> cources = new ArrayList<Cource>();

    public void addCource(Cource c){
        cources.add(c);
    }
    public void printCource(){
        for(int i = 0; i < cources.size(); i++){
            System.out.println();
        }
    }
}
