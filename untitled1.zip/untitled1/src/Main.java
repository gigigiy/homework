import java.util.ArrayList;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
    PersonalAccount pa = new PersonalAccount(1,"Timur");
        System.out.println(pa.getBalance());
        pa.deposit(2000);
        pa.deposit(300);
        pa.withdraw(2500);
        System.out.println(pa.getBalance());
        pa.printTransactionHistory();
        System.out.println("result" +"->"+ pa.getBalance());


    }
}